$(document).ready(function () {
    $('.menu').on('click', function () {
        $('ul').toggleClass('show');
        $('.btn').toggleClass('show');
    })
})